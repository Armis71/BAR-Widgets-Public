Since the banner (header.png) is not baked into the program, you can actually change it. 

Make sure  it's:

PNG format,
~100px tall,
any width

The total height of the program is 1000px with no resize. If you put a taller banner, it will push down on the interface below, so make sure it's only 100px. 